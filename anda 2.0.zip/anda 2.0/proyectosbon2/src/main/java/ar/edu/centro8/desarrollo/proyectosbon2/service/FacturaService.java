package ar.edu.centro8.desarrollo.proyectosbon2.service;

import ar.edu.centro8.desarrollo.proyectosbon2.model.Factura;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.FacturaRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FacturaService {

    @Autowired
    private FacturaRepository facturaRepository;

    public List<Factura> buscarPorFormaDePago(String formaDePago) {
        return facturaRepository.findByFormaDePagoContaining(formaDePago);
    }

    public List<Factura> buscarFacturasPorFormaDePagoSimilar(String formaDePago) {
        return facturaRepository.findByFormaDePagoLike(formaDePago);
    }

}