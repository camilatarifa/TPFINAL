package ar.edu.centro8.desarrollo.proyectosbon2.controller;

//import ar.edu.centro8.desarrollo.proyectojpanam.dto.SucursalRequestDTO;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Sucursal;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Producto;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.SucursalRepository;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.ProductoRepository;
//import ar.edu.centro8.desarrollo.proyectojpanam.services.SucursalService;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sucursales")
public class SucursalController {
    @Autowired
    private SucursalRepository sucursalRepository;

    // @Autowired
    // private SucursalService sucursalService;

    @GetMapping
    public void traerSucursal() {
        List<Sucursal> sucursales = sucursalRepository.findAll();
    }

    @GetMapping("/{id}")
    public void traerCursoPorId(@PathVariable Long id) {
        sucursalRepository.findById(id);
    }

    // @PostMapping
    // public void crearSucursal(@RequestBody Sucursal sucursal) {
    // sucursalRepository.save(sucursal);
    // }

    // @PutMapping ("/editar/curso/{id_original}")
    // public void editarCurso (@PathVariable Long id_original,
    // @RequestParam(required = false, name = "id") Long nuevaId,
    // @RequestParam(required = false, name = "nombre") String nuevoNombre
    // ) {
    // Optional<Sucursal> optionalCurso = sucursalRepository.findById(id_original);
    // if (optionalCurso.isPresent()) {
    // Sucursal existingCurso = optionalCurso.get();
    // existingCurso.setNombre(nuevoNombre);
    // sucursalRepository.save(existingCurso);
    // } else {
    // // Manejar el caso en que el curso no existe
    // }
    // }

    @DeleteMapping("/{id}")
    public void eliminarCurso(@PathVariable Long id) {
        sucursalRepository.deleteById(id);
    }

    // @PostMapping
    // public ResponseEntity<Sucursal> crearSucursal(@RequestBody SucursalRequestDTO
    // sucursalRequest) {
    // Sucursal sucursal =
    // sucursalService.crearSucursalConEstudiante(sucursalRequest);
    // return ResponseEntity.status(HttpStatus.CREATED).body(sucursal);
    // }

}
