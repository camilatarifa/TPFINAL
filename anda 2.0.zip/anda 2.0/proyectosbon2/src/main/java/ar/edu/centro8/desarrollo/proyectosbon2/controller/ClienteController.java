package ar.edu.centro8.desarrollo.proyectosbon2.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Cliente;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.ClienteRepository;
import ar.edu.centro8.desarrollo.proyectosbon2.service.ClienteService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })
public class ClienteController {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private ClienteService clienteService;

    @GetMapping("/cliente/traer")
    public List<Cliente> traerClientes() {
        return clienteRepository.findAll();
    }

    @GetMapping("/cliente/traer/{id}")
    public Optional<Cliente> traerUnCliente(@PathVariable Long id) {
        return clienteRepository.findById(id);
    }

    @PostMapping("/cliente/crear")
    public void crearCliente(@RequestBody Cliente c) {
        clienteRepository.save(c);
    }

    @DeleteMapping("/cliente/borrar/{id}")
    public String borrarUnCliente(@PathVariable Long id) {
        clienteRepository.deleteById(id);
        return "cliente eliminada correctamente";
    }

    @PutMapping("/cliente/actualizar/{id}")
    public String actualizarUnCliente(@PathVariable Long id, @RequestBody Cliente c) {

        Cliente clienteBuscada = clienteRepository.findById(id).get();

        clienteBuscada.setNombre(c.getNombre());
        clienteBuscada.setDomicilio(c.getDomicilio());
        clienteBuscada.setTelefono(c.getTelefono());

        clienteRepository.save(clienteBuscada);

        return "Datos de la cliente actualizada correctamente";
    }

    @GetMapping("cliente/buscar/{nombre}")
    public ResponseEntity<List<Cliente>> buscarPorNombre(@PathVariable String nombre) {
        List<Cliente> clientes = clienteService.buscarPorNombre(nombre);
        return ResponseEntity.ok(clientes);
    }

    @GetMapping("cliente/buscarSimilar/{cadena}")
    public ResponseEntity<List<Cliente>> buscarPorNombreSimilar(@PathVariable String cadena) {
        List<Cliente> clientes = clienteService.buscarClientesPorNombreSimilar(cadena);
        return ResponseEntity.ok(clientes);
    }

}
