/*
 La llamada optionalEstudiante.isPresent() realiza la siguiente función:

Comprueba si hay un valor presente dentro del Optional.
Devuelve un booleano:
Si hay un valor presente, devuelve true.
Si no hay ningún valor, devuelve false.
Es una forma de verificar si el Optional contiene algún elemento sin acceder directamente al contenido.



Optional es una clase en Java que representa un valor que puede o no estar presente. Es parte del paquete java.util y fue introducido en Java 8. Sus principales características son:

Representa un valor que puede o no estar presente.
Permite manejar casos donde un valor podría no existir sin necesidad de usar null.
Ofrece métodos para verificar si tiene un valor y acceder a él de manera segura.
Es particularmente útil en combinación con funciones lambda y expresiones de interfaz.
Es usado por Spring Data JPA en métodos como findById() para indicar que el resultado puede ser nulo.
 */

package ar.edu.centro8.desarrollo.proyectosbon2.controller;

import ar.edu.centro8.desarrollo.proyectosbon2.model.Sucursal;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Producto;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/producto")
public class ProductoController {

    @Autowired
    private ProductoRepository productoRepository;

    @GetMapping("/traer")
    public void traerProductos() {
        List<Producto> productos = productoRepository.findAll();
    }

    @GetMapping("/traer/{id}")
    public void traerProductoPorId(@PathVariable Long id) {
        productoRepository.findById(id);
    }

    @PostMapping("/crear")
    public void crearProducto(@RequestBody Producto producto) {
        productoRepository.save(producto);
    }

    @PutMapping("/editar/{id_original}")
    public void editarProducto(@PathVariable Long id_original,
            @RequestParam(required = false, name = "id") Long nuevaId,
            @RequestParam(required = false, name = "nombre") String nuevoNombreProducto) {
        Optional<Producto> optionalProducto = productoRepository.findById(id_original);
        if (optionalProducto.isPresent()) {
            Producto existingProducto = optionalProducto.get();
            existingProducto.setNombre_producto(nuevoNombreProducto);
            productoRepository.save(existingProducto);
        } else {
            // Manejar el caso en que el estudiante no existe
        }

    }

    @DeleteMapping("/eliminar/{id}")
    public String eliminarProducto(@PathVariable Long id) {
        productoRepository.deleteById(id);
        return "producto eliminado correctamente";
    }

}
