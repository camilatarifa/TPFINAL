-- Active: 1730936067665@@127.0.0.1@3306@cafeteria
-- drop database if exists cafeteria;
-- create database cafeteria;
-- use cafeteria;
DROP DATABASE IF EXISTS chino2;
CREATE DATABASE chino2;
USE chino2;

CREATE TABLE clientes (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY, 
    nombre VARCHAR(50) NOT NULL,
    domicilio VARCHAR(50) NOT NULL,
    telefono VARCHAR(10)
/*     dni CHAR(8) NOT NULL,   
email VARCHAR(50),
    clave varchar(50)*/
);

CREATE TABLE sucursales(
    id_sucursal INT PRIMARY KEY,
    localidad VARCHAR(50),
    direccion VARCHAR(70),
    producto varchar(50)
    -- FOREIGN KEY (codigo_sucursal) REFERENCES productos(codigo_sucursal)
);

CREATE TABLE productos(
    id_sucursal INT NOT NULL,
	id_producto INT PRIMARY KEY,
    categoria VARCHAR(50),
    producto varchar(50),
    precio double,
    stock_actual INT NOT NULL,
    stock_minimo INT NOT NULL,
    stock_maximo INT NOT NULL,
    FOREIGN KEY (id_sucursal) REFERENCES sucursales(id_sucursal)
);

CREATE TABLE facturas(
    letra CHAR(1) NOT NULL,
    nro_pedido INT PRIMARY KEY AUTO_INCREMENT,
    fecha DATE NOT NULL,
    id_producto INT NOT NULL,
    id_cliente INT NOT NULL,
    id_sucursal INT NOT NULL,
    forma_de_pago VARCHAR(50) NOT NULL,
    -- Parece que no hay estrictamente el tipo de dato String en MySQL, pero hay equivalentes como CHAR() o VARCHAR()
    -- No hace diferencia/ no habrá error al colocar aquí VARCHAR y en Java String para el mismo campo, porque equivale
    FOREIGN KEY (id_producto) REFERENCES productos(id_producto),
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
    -- FOREIGN KEY (id_sucursal) REFERENCES sucursales(codigo_sucursal)
);


-- -----------------------------------------------------------------------------------------------------------
    
INSERT INTO clientes (nombre, domicilio, telefono) VALUES
    ('Juan Perez', 'Corrientes 2678', '987654321'),
    ('María Flores', 'Florida 876', '87654321'),
    ('Carlos Rodriguez', 'Cabildo 4321', '23456789'),
    ('Lucía Franco', 'Thames 543', '34567812'),
    ('Martín Díaz', 'Santa Fe 1890', '98765432'),
    ('Carolina López', 'Lavalle 300', '45678123'),
    ('Fernando Martínez', 'Rivadavia 5678', '78901234'),
    ('Valeria García', 'Juan B. Justo 4321', '12345678'),
    ('Miguel Sánchez', 'Scalabrini Ortiz 2765', '56781234'),
    ('Camila Fernández', 'Gorriti 234', '12347890'),
    ('Diego Britos', 'Honduras 1765', '78904561'),
    ('Brenda Giménez', 'Billinghurst 543', '34561230'),
    ('Marcelo Alvarez', 'Borges 4321', '78904561'),
    ('Romina Smith', 'Gurruchaga 1765', '34561230'),
    ('Eduardo Romero', 'Rivadavia 7890', '12034567');
SELECT * FROM clientes;

    INSERT INTO sucursales (id_sucursal, localidad, direccion) values
    (1, 'Villa del Parque', 'Av. Corrientes 4200'),
    (2, 'Villa Devoto', 'Calle Arenal 1350'),
    (3, 'Villa Crespo', 'Av. Santa Fe 5200'),
    (4, 'Villa Luro', 'Calle Guise 2150'),
    (5, 'Balvanera', 'Av. 9 de Julio 1900');

INSERT INTO productos(id_sucursal, id_producto, categoria, producto, precio, stock_actual, stock_minimo, stock_maximo) VALUES
    ('1', '1', 'bebida', 'Mocaccino', '2400','100', '10', '150'),
    ('2', '2', 'bebida','Iced Americano', '2400', '80', '5', '120'),
    ('3', '3', 'bebida','Expresso', '2400', '50', '8', '80'),
    ('4', '4', 'bebida','Chai latte', '2400', '30', '5', '50'),
    ('5', '5', 'panaderia_pasteleria','Muffin', '1000', '60', '10', '80'),
    ('1', '6', 'panaderia_pasteleria','Medialuna', '400', '40', '8', '60'),
    ('2', '7', 'panaderia_pasteleria','Tostado', '800', '25', '5', '40'),
    ('3', '8', 'panaderia_pasteleria','Waffles', '1200', '20', '5', '30'),
    ('4', '9', 'panaderia_pasteleria','Alfajor de Maicena', '300', '15', '3', '25'),
    ('5', '10', 'panaderia_pasteleria','Dona', '600', '35', '7', '55'),
    ('1', '11', 'panaderia-pasteleria','Churro', '400', '28', '6', '45'),
    ('2', '12', 'bebida','Matcha latte', '2400', '22', '4', '35'),
    ('3', '13', 'bebida','Cortado', '2400', '50', '10', '70'),
    ('4', '14', 'bebida','Submarino', '3600', '50', '10', '70'),
    ('5', '15', 'panaderia_pasteleria','Pretzel', '700', '50', '10', '70'),
    ('1', '16', 'panaderia_pasteleria','Budin Marmolado', '1700', '50', '10', '70'),
    ('2', '17', 'panaderia_pasteleria','Pebete', '1300', '50', '10', '70'),
    ('3', '18', 'panaderia_pasteleria','rainbow cake', '3600', '50', '10', '70'),
    ('4', '19', 'panaderia_pasteleria','Sanguchito de Miga', '800', '50', '10', '70'),
    ('5', '20', 'panaderia_pasteleria','torta red velvet', '3700', 50, 10, 70),
    ('1', '21', 'bebida','limonada con jengibre y menta', '1400', '50', '10', '70'),
    ('2', '22', 'bebida','limonada de maracuya', '150', '50', '1400', '70'),
    ('3', '23', 'panaderia_pasteleria','mousse de chocolate', '4000', '50', '10', '70');
    
select * from productos;

INSERT INTO facturas (nro_pedido, forma_de_pago) VALUES -- letra, fecha, id_producto, id_cliente, id_sucursal,
    (1, 'efectivo'), -- 'A', '2023-01-01', 1, 1, 1
    (2, 'tarjeta'), -- 'B', CURDATE(), 2, 2, 2
    (3, 'efectivo'), -- 'C', '2023-02-03', 3, 3, 3
    (4, 'efectivo'), -- 'A', '2023-06-04', 4, 4, 4
    (5, 'tarjeta'), -- 'B', CURDATE(), 5, 5, 5
    (6, 'efectivo'), -- 'C', '2023-11-06', 6, 6, 1
    (7, 'tarjeta'), -- 'A', '2023-01-01', 7, 7, 2
    (8, 'efectivo'), -- 'B', '2023-09-10', 8, 8, 3
    (9, 'tarjeta'), -- 'B', '2023-08-09', 9, 9, 4
    (10, 'efectivo'), -- 'C', '2023-03-25', 10, 10, 5
    (11, 'tarjeta'), -- 'C', '2023-07-30', 11, 11, 1
    (12, 'tarjeta'), -- 'A', '2023-04-02', 12, 12, 2
    (13, 'efectivo'), -- 'C', '2023-01-13', 13, 13, 3
    (14, 'tarjeta'), -- 'A', '2023-12-14', 14, 14, 4
    (15, 'efectivo'); -- 'B', '2023-12-14', 15, 15, 5
select * from facturas;