package ar.edu.centro8.tp.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.integration.IntegrationProperties.RSocket.Client;
import org.springframework.stereotype.Service;
import java.util.List;
import ar.edu.centro8.tp.dto.FacturaRequestDTO;
import ar.edu.centro8.tp.dto.ClienteRequestDTO;
import ar.edu.centro8.tp.Model.Factura;
import ar.edu.centro8.tp.Model.Cliente;
import ar.edu.centro8.tp.Repository.FacturaRepository;
import ar.edu.centro8.tp.Repository.IClienteRepository;
import jakarta.transaction.Transactional;

// uno a mucho
@Service
@Transactional
public class FacturaService {
    @Autowired
    private FacturaRepository facturaRepository;

    @Autowired
    private IClienteRepository IClienteRepository;

    public List<Factura> obtenerConcesionarias() {
        return facturaRepository.findAll();
    }

    public Factura guardarFactura(Factura factura) {
        return facturaRepository.save(factura);
    }

    public boolean eliminarFactura(Long id) {
        try {
            facturaRepository.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public Factura traerFactura(Long id) {
        return facturaRepository.findById(id).orElse(null);
    }

    public Factura editarFactura(Long idOriginal, Long idNueva, int nro_pedido, int id_producto, int id_cliente,
            int id_sucursal, String forma_de_pago) {
        Factura factura = traerFactura(idOriginal);
        if (factura != null) {
            factura.setId(idNueva);
            factura.setNro_pedido(nro_pedido);
            factura.setId_producto(id_producto);
            factura.setId_cliente(id_cliente);
            factura.setId_sucursal(id_sucursal);
            factura.setForma_de_pago(forma_de_pago);
            return guardarFactura(factura);
        }
        return null;
    }

    public Cliente guardarCliente(Cliente cliente) {
        return IClienteRepository.save(cliente);
    }

}
