package ar.edu.centro8.tp.Service;

import java.util.List;
import ar.edu.centro8.tp.Model.Cliente;

public interface IClienteService {
    // método para traer a todas las personas
    // lectura
    public List<Cliente> getClientes();

    // alta
    public void saveCliente(Cliente cliente);

    // baja
    public void deleteCliente(Long id);

    // lectura de un solo objeto
    public Cliente findCliente(Long id);

    // edición/modificación
    public void editarCliente(Long idOriginal, Long idNueva,
            String nuevoNombre,
            String nuevoDomicilio,
            String nuevoTelefono);
}
