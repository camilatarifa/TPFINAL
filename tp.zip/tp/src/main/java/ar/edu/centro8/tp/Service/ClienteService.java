package ar.edu.centro8.tp.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.edu.centro8.tp.Model.Cliente;
import ar.edu.centro8.tp.Repository.IClienteRepository;

@Service
public class ClienteService implements IClienteService {

    @Autowired
    private IClienteRepository persoRepo;

    @Override
    public List<Cliente> getClientes() {
        List<Cliente> listaPersonas = persoRepo.findAll();
        return listaPersonas;
    }

    @Override
    public void saveCliente(Cliente cliente) {
        persoRepo.save(cliente);
    }

    @Override
    public void deleteCliente(Long id) {
        persoRepo.deleteById(id);
    }

    @Override
    public Cliente findCliente(Long id) {
        Cliente cliente = persoRepo.findById(id).orElse(null);
        return cliente;
    }

    @Override
    public void editarCliente(Long idOriginal, Long idNueva, String nuevoNombre, String nuevoDomicilio,
            String nuevoTelefono) {
        // busco el objeto original
        Cliente cliente = this.findCliente(idOriginal);

        // proceso de modificación a nivel lógico
        cliente.setId(idNueva);
        cliente.setNombre(nuevoNombre);
        cliente.setDomicilio(nuevoDomicilio);
        cliente.setTelefono(nuevoTelefono);

        // guardar los cambios
        this.saveCliente(cliente);
    }

}
