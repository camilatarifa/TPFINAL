package ar.edu.centro8.tp.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.centro8.tp.Model.Factura;

public interface FacturaRepository extends JpaRepository<Factura, Long> {

}
