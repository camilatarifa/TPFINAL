// -----------------------------------------------------------------

/*El anotador @Data de Lombok genera los siguientes métodos automáticamente para la clase anotada:

Constructor vacío (default())
Constructor con todos los campos (allArgsConstructor())
Método getter para cada campo (getter())
Método setter para cada campo (setter())
Método toString() que incluye todos los campos de la clase
Método equals() y hashCode() basados en todos los campos de la clase*/

// -- package ar.edu.centro8.desarrollo.proyectosbon2.model;

// import lombok.Data;

// @Data
// public class Producto {
    
//     private Long id_producto;
//     private String codigo_sucursal;
//     private String categoria;
//     private String producto;
//     private Double precio;
//     private int stock_actual;
//     private int stock_minimo;
//     private int stock_maximo;
//     //private Instant fechaActualizacion;

// }

// --------------------------intento anterior------------------------------------

// package ar.edu.centro8.desarrollo.proyectojpanam.models;

// import java.util.List;

// import com.fasterxml.jackson.annotation.JsonBackReference;

// import jakarta.persistence.CascadeType;
// import jakarta.persistence.Column;
// import jakarta.persistence.Entity;
// import jakarta.persistence.FetchType;
// import jakarta.persistence.GeneratedValue;
// import jakarta.persistence.GenerationType;
// import jakarta.persistence.Id;
// import jakarta.persistence.JoinColumn;
// import jakarta.persistence.JoinTable;
// import jakarta.persistence.ManyToMany;
// import lombok.Getter;
// import lombok.NoArgsConstructor;
// import lombok.Setter;
// import java.util.ArrayList;

// @Entity
// @NoArgsConstructor
// @Getter @Setter
// public class Producto {
//     @Id
//     @Column(name = "id_producto", nullable = false)
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private Long id;

//     @Column(name = "id_sucursal", nullable = false)
//     private String idSucursal;

// -------------los siguientes import no recuerdo de qué clase/proyecto eran,
// pero por si acaso en lugar de borrarlos sólo los comenté -------------

// import java.util.ArrayList;

// import com.fasterxml.jackson.annotation.JsonBackReference;

// import jakarta.persistence.Column;
// import jakarta.persistence.Entity;
// import jakarta.persistence.FetchType;
// import jakarta.persistence.GeneratedValue;
// import jakarta.persistence.GenerationType;
// import jakarta.persistence.JoinColumn;
// import jakarta.persistence.JoinTable;
// import jakarta.persistence.ManyToMany;
// import lombok.Data;
// import lombok.Getter;
// import lombok.NoArgsConstructor;
// import lombok.Setter;

// ---------------------ahora sí, lo siguiente hace parte del intento anterior-----------------------------

// por cierto, esta parte incluye fetch, la parte de "sucursal" no lo incluía de esta manera,
// de ahí que utilicé la clase "Sucursal" actual como plantilla para la clase "Producto" que no está comentada

//     @Column(name = "producto", nullable = false)
//     private String producto;

//     @Column(name = "precio", nullable = false)
//     private String precio;

//     @Column(name = "stock_actual", nullable = false)
//     private String stockActual;

//     @Column(name = "stock_minimo", nullable = false)
//     private String stockMinimo;

//     @Column(name = "stock_maximo", nullable = false)
//     private String stockMaximo;

//     @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//     @JsonBackReference
//     @JoinTable(
//         name = "producto_sucursal", joinColumns = @JoinColumn(name = "codigo_sucursal", referencedColumnName = "id"),
//         inverseJoinColumns = @JoinColumn(name = "codigo_sucursal", referencedColumnName = "id")
//     )
//     private List<Sucursal>  = new ArrayList<>();

//     public Producto(String nombre, List<Curso> cursos) {
//         this.nombre = nombre;
//         this.cursos = cursos;
//     }

//     public Estudiante(String nombre) {
//         this.nombre = nombre;
//     }

//     public void agregarCurso(Sucursal curso) {
//         if (cursos == null) {
//             cursos = new ArrayList<>();
//         }
//         cursos.add(curso);
//     }
// }
