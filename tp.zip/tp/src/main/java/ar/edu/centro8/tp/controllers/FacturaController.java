package ar.edu.centro8.tp.controllers;

import ar.edu.centro8.tp.Repository.FacturaRepository;
import ar.edu.centro8.tp.Service.FacturaService;
import ar.edu.centro8.tp.dto.FacturaRequestDTO;
import ar.edu.centro8.tp.Model.Factura;
import ar.edu.centro8.tp.Model.Cliente;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/facturas")
public class FacturaController {
    @Autowired
    private FacturaService facturaService;

    @GetMapping
    public Factura getFacturaById(@PathVariable Long id) {
        return facturaService.traerFactura(id);
    }

    @GetMapping("/{id}")
    public Factura traerFacturaPorId(@PathVariable Long id) {
        return facturaService.traerFactura(id);
    }

    @PutMapping("/editar/factura/{id_original}")
    public void editarFactura(@PathVariable Long id, @RequestBody Factura factura) {
        facturaService.editarFactura(id, factura.getId(), factura.getNro_pedido(), factura.getId_producto(),
                factura.getId_cliente(), factura.getId_sucursal(), factura.getForma_de_pago());
    }
    // int nro_pedido, int id_producto, int id_cliente, int id_sucursal, String
    // forma_de_pago,

    @DeleteMapping("/{id}")
    public void eliminarFactura(@PathVariable Long id) {
        facturaService.eliminarFactura(id);
    }

    @PostMapping
    public void createFactura(@RequestBody Factura factura) {
        facturaService.guardarFactura(factura);
    }
}
