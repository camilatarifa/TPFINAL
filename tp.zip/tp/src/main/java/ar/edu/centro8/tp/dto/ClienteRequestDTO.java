package ar.edu.centro8.tp.dto;

public class ClienteRequestDTO {

}
