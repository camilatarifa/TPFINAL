// package ar.edu.centro8.tp.Service;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;

// import ar.edu.centro8.tp.dto.SucursalRequestDTO;
// import ar.edu.centro8.tp.dto.ProductoRequestDTO;
// import ar.edu.centro8.tp.Model.Sucursal;
// import ar.edu.centro8.tp.Model.Producto;
// import ar.edu.centro8.tp.Repository.SucursalRepository;
// import ar.edu.centro8.tp.Repository.ProductoRepository;

// import jakarta.transaction.Transactional;

// @Service
// public class SucursalService {
// @Autowired
// private SucursalRepository sucursalRepository;

// @Transactional
// public Sucursal crearSucursalConProducto(SucursalRequestDTO sucursalRequest)
// {
// Sucursal sucursal = new Sucursal(sucursalRequest.getNombre());

// for (ProductoRequestDTO producto : sucursalRequest.getProducto()) {
// Producto productoNuevo = new Producto(producto.getNombre());
// productoNuevo.agregarSucursal(sucursal);
// sucursal.agregarProducto(productoNuevo);
// productoRepository.save(productoNuevo);
// }

// return sucursalRepository.save(sucursal);
// }
// }
