package ar.edu.centro8.tp.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class FacturaRequestDTO {
   // private String letra; //lo comentareo xq en una parte estaba como char
   private int nro_pedido;
   private int id_producto;
   private int id_cliente;
   private int id_sucursal;
   private String forma_de_pago;
   private List<ProductoRequestDTO> productos;
   private List<SucursalRequestDTO> sucursal;
}
