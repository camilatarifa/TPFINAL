package ar.edu.centro8.tp.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ar.edu.centro8.tp.Model.Cliente;
import ar.edu.centro8.tp.Service.IClienteService;

@RestController
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })
public class ClienteController {

    @Autowired
    private IClienteService clienteServ;

    @GetMapping("/clientes/traer")
    public List<Cliente> getClientes() {
        return clienteServ.getClientes();
    }

    @PostMapping("/clientes/crear")
    public String saveCliente(@RequestBody Cliente cliente) {
        clienteServ.saveCliente(cliente);

        return "El cliente fue creado";
    }

    @DeleteMapping("/clientes/borrar/{id}")
    public String deleteCliente(@PathVariable Long id) {
        clienteServ.deleteCliente(id);
        return "Cliente eliminado";
    }

    @PutMapping("/clientes/editar/{id_original}")
    public Cliente editarCliente(@PathVariable Long id_original,
            @RequestParam(required = false, name = "id") Long nuevaId,
            @RequestParam(required = false, name = "id_cliente") int nuevaId_cliente,
            @RequestParam(required = false, name = "nombre") String nuevoNombre,
            @RequestParam(required = false, name = "domicilio") String nuevoDomicilio,
            @RequestParam(required = false, name = "telefono") String nuevoTelefono) {

        clienteServ.editarCliente(id_original, nuevaId, nuevoNombre, nuevoDomicilio, nuevoTelefono);

        Cliente cliente = clienteServ.findCliente(nuevaId);

        return cliente;

    }
}
