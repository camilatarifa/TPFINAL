package ar.edu.centro8.tp.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ar.edu.centro8.tp.Model.Cliente;

@Repository
public interface IClienteRepository extends JpaRepository<Cliente, Long> {

}
