package ar.edu.centro8.tp.Model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.ArrayList;
import ar.edu.centro8.tp.Model.Cliente;

@Entity
@NoArgsConstructor
@Getter
@Setter
public class Factura {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_factura", nullable = false)
    private Long id;

    @Column(name = "nro_pedido", nullable = false)
    private int nro_pedido;
    @Column(name = "id_producto", nullable = false)
    private int id_producto;
    @Column(name = "id_cliente", nullable = false)
    private int id_cliente;
    @Column(name = "id_sucursal", nullable = false)
    private int id_sucursal;
    @Column(name = "forma_de_pago", nullable = false)
    private String forma_de_pago;

    @OneToMany(mappedBy = "factura", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<Cliente> clientes;

    public Factura(int nro_pedido, int id_producto, int id_cliente, int id_sucursal, String forma_de_pago,
            List<Cliente> clientes) {
        this.nro_pedido = nro_pedido;
        this.id_producto = id_producto;
        this.id_cliente = id_cliente;
        this.forma_de_pago = forma_de_pago;
        this.clientes = clientes;
    }

    public Cliente agregarCliente(Cliente cliente) {
        this.clientes.add(cliente);
        return cliente;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + nro_pedido;
        result = prime * result + ((clientes == null) ? 0 : clientes.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Factura other = (Factura) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;

        if (nro_pedido != other.nro_pedido) // Comparación con nro_pedido
            return false;

        if (clientes == null) {
            if (other.clientes != null)
                return false;
        } else if (!clientes.equals(other.clientes))
            return false;

        return true;
    }

}
