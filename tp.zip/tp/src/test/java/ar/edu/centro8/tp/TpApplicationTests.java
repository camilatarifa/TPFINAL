package ar.edu.centro8.tp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpApplicationTests {

	@Test
	void contextLoads() {
	}

}
