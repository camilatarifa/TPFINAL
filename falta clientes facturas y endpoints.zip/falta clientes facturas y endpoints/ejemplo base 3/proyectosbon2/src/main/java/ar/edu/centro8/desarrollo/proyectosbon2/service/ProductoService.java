package ar.edu.centro8.desarrollo.proyectosbon2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// import ar.edu.centro8.desarrollo.proyectosbon2.dto.SucursalRequestDTO;
// import ar.edu.centro8.desarrollo.proyectosbon2.dto.ProductoRequestDTO;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Sucursal;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Producto;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.SucursalRepository;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.ProductoRepository;
import jakarta.transaction.Transactional;

@Service
public class ProductoService {
    @Autowired
    private ProductoRepository productoRepository;

    public List<Producto> getAllProductos() {
        return productoRepository.findAll();
    }

    public Optional<Producto> getProductoById(Long id) {
        return productoRepository.findById(id); //.orElse("Producto no encontrado.");
    }

    public Producto crearProducto(Producto producto) {
        return productoRepository.save(producto);
    }

    public Producto saveProducto(Producto producto) {
        return productoRepository.save(producto);
    }

    public void deleteProducto(Long id) {
        productoRepository.deleteById(id);
    }

    // @Transactional
    // public Sucursal crearSucursalConProducto(SucursalRequestDTO sucursalRequest) {
    //     Sucursal sucursal = new Sucursal(sucursalRequest.getNombre());

    //     for (ProductoRequestDTO producto : sucursalRequest.getProducto()) {
    //         Producto productoNuevo = new Producto(producto.getNombre());
    //         productoNuevo.agregarSucursal(sucursal);
    //         sucursal.agregarProducto(productoNuevo);
    //         productoRepository.save(productoNuevo);
    //     }

    //     return sucursalRepository.save(sucursal);
    // }
}
