package ar.edu.centro8.desarrollo.proyectosbon2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.edu.centro8.desarrollo.proyectosbon2.dto.SucursalRequestDTO;
import ar.edu.centro8.desarrollo.proyectosbon2.dto.ProductoRequestDTO;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Sucursal;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Producto;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.SucursalRepository;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.ProductoRepository;
import jakarta.transaction.Transactional;

@Service
public class SucursalService {
    @Autowired
    private SucursalRepository sucursalRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Transactional
    public Sucursal crearSucursalConProducto(SucursalRequestDTO sucursalRequest) {
        Sucursal sucursal = new Sucursal();

        for (ProductoRequestDTO producto : sucursalRequest.getProductos()) {
            Producto productoNuevo = new Producto(producto.getNombre());
            productoNuevo.agregarSucursal(sucursal);
            sucursal.agregarProducto(productoNuevo);
            productoRepository.save(productoNuevo);
        }

        return sucursalRepository.save(sucursal);
    }
}
