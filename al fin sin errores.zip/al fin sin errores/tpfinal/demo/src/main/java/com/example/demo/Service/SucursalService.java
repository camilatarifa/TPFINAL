package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.SucursalRequestDTO;
import com.example.demo.dto.ProductoRequestDTO;
import com.example.demo.Model.Sucursal;
import com.example.demo.Model.Producto;
import com.example.demo.Repository.SucursalRepository;
import com.example.demo.Repository.ProductoRepository;
import jakarta.transaction.Transactional;

@Service
public class SucursalService {
    @Autowired
    private SucursalRepository sucursalRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Transactional
    public Sucursal crearSucursalConProducto(SucursalRequestDTO sucursalRequest) {
        Sucursal sucursal = new Sucursal();

        for (ProductoRequestDTO producto : sucursalRequest.getProductos()) {
            Producto productoNuevo = new Producto(producto.getNombre());
            productoNuevo.agregarSucursal(sucursal);
            sucursal.agregarProducto(productoNuevo);
            productoRepository.save(productoNuevo);
        }

        return sucursalRepository.save(sucursal);
    }
}
