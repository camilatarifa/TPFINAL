package ar.edu.centro8.desarrollo.proyectojpanam.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class CursoRequestDTO {
    private String nombre;
    private List<EstudianteRequestDTO> estudiantes; 
}
