package ar.edu.centro8.desarrollo.proyectojpanam.controllers;

import ar.edu.centro8.desarrollo.proyectojpanam.dto.CursoRequestDTO;
import ar.edu.centro8.desarrollo.proyectojpanam.models.Curso;
import ar.edu.centro8.desarrollo.proyectojpanam.models.Estudiante;
import ar.edu.centro8.desarrollo.proyectojpanam.repositories.CursoRepository;
import ar.edu.centro8.desarrollo.proyectojpanam.repositories.EstudianteRepository;
import ar.edu.centro8.desarrollo.proyectojpanam.services.CursoService;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cursos")
public class CursoController {
    @Autowired
    private CursoRepository cursoRepository;

    @Autowired
    private CursoService cursoService;

    @GetMapping
    public void traerCursos() {
        List<Curso> cursos = cursoRepository.findAll();
    }

    @GetMapping("/{id}")
    public void traerCursoPorId(@PathVariable Long id) {
        cursoRepository.findById(id);
    }

    // @PostMapping
    // public void crearCurso(@RequestBody Curso curso) {
    //     cursoRepository.save(curso);
    // }

    
    @PutMapping ("/editar/curso/{id_original}")
    public void editarCurso (@PathVariable Long id_original,
        @RequestParam(required = false, name = "id") Long nuevaId,
        @RequestParam(required = false, name = "nombre") String nuevoNombre
        ) {
            Optional<Curso> optionalCurso = cursoRepository.findById(id_original);
if (optionalCurso.isPresent()) {
    Curso existingCurso = optionalCurso.get();
    existingCurso.setNombre(nuevoNombre);
    cursoRepository.save(existingCurso);
} else {
    // Manejar el caso en que el curso no existe
}
    }

    @DeleteMapping("/{id}")
    public void eliminarCurso(@PathVariable Long id) {
        cursoRepository.deleteById(id);
    }

    @PostMapping
    public ResponseEntity<Curso> crearCurso(@RequestBody CursoRequestDTO cursoRequest) {
        Curso curso = cursoService.crearCursoConEstudiante(cursoRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(curso);
    }

}
