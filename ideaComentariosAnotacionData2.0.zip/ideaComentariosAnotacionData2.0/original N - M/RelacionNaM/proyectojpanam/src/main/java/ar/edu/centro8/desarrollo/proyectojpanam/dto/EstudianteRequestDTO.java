package ar.edu.centro8.desarrollo.proyectojpanam.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class EstudianteRequestDTO {
    private String nombre;
}
