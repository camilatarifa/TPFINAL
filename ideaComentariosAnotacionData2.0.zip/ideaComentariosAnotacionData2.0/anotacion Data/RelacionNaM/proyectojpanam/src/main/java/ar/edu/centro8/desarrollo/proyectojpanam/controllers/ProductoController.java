/*
La llamada optionalEstudiante.isPresent() realiza la siguiente función:

Comprueba si hay un valor presente dentro del Optional.
Devuelve un booleano:
Si hay un valor presente, devuelve true.
Si no hay ningún valor, devuelve false.
Es una forma de verificar si el Optional contiene algún elemento sin acceder directamente al contenido.



Optional es una clase en Java que representa un valor que puede o no estar presente. Es parte del paquete java.util y fue introducido en Java 8. Sus principales características son:

Representa un valor que puede o no estar presente.
Permite manejar casos donde un valor podría no existir sin necesidad de usar null.
Ofrece métodos para verificar si tiene un valor y acceder a él de manera segura.
Es particularmente útil en combinación con funciones lambda y expresiones de interfaz.
Es usado por Spring Data JPA en métodos como findById() para indicar que el resultado puede ser nulo.
 */

package ar.edu.centro8.desarrollo.proyectojpanam.controllers;

import ar.edu.centro8.desarrollo.proyectojpanam.models.Sucursal;
import ar.edu.centro8.desarrollo.proyectojpanam.models.Producto;
import ar.edu.centro8.desarrollo.proyectojpanam.repositories.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/productos")
public class ProductoController {

    @Autowired
    private ProductoRepository productoRepo;

    @GetMapping
    public void traerProductos() {
        List<Producto> productos = productoRepo.findAll();
    }

    @GetMapping("/{idProducto}")
    public void traerProductoPorId(@PathVariable Long idProducto) {
        productoRepo.findById(idProducto);
    }

    @PostMapping
    public void crearProducto(@RequestBody Producto producto) {
        productoRepo.save(producto);
    }

    @PutMapping("/editar/producto/{idProducto}")
    public void editarProducto(@PathVariable Long idProducto,
            @RequestParam(required = false, name = "id") Long nuevaId,
            @RequestParam(required = false, name = "nombre") String nuevoNombre) {
        Optional<Producto> optionalProducto = productoRepo.findById(idProducto);
        if (optionalProducto.isPresent()) {
            Producto existingProducto = optionalProducto.get();
            existingProducto.setNombre(nuevoNombre);
            productoRepo.save(existingProducto);
        } else {
            // Manejar el caso en que el producto no existe
        }

    }

    @DeleteMapping("/{idProducto}")
    public void eliminarProducto(@PathVariable Long idProducto) {
        productoRepo.deleteById(idProducto);
    }

    // Original N - M - PersonaController
    //ideaProductos: que podamos buscar un producto por id (principalmente), (secundario: buscar por nombre)
    //ideaSucursales: que podamos buscar una sucursal por localidad (principalmente), (secundario: buscar por dirección)
    //¿qué opinas? ajsjdjsjj tenía al revés las prioridades
    // Igual podemos cambiar el servicio, tampoco estoy segura de si
    // todas las entidades deben tener capa de servicio alv

//     @RestController
// @RequestMapping("/api")
// @CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
//         RequestMethod.DELETE })
// public class PersonaController {

//     @Autowired
//     private PersonaRepository persoRepo;

//     @Autowired
//     private PersonaService personaService;

//     @GetMapping("/persona/traer")
//     public List<Persona> traerPersonas() {
//         return persoRepo.findAll();
//     }

//     @GetMapping("/persona/traer/{id}")
//     public Optional<Persona> traerUnaPersona(@PathVariable Long id) {
//         return persoRepo.findById(id);
//     }

//     @PostMapping("/persona/crear")
//     public void crearPersona(@RequestBody Persona p) {
//         persoRepo.save(p);
//     }

//     @DeleteMapping("/persona/borrar/{id}")
//     public String borrarUnaPersona(@PathVariable Long id) {
//         persoRepo.deleteById(id);
//         return "persona eliminada correctamente";
//     }

//     @PutMapping("/persona/actualizar/{id}")
//     public String actualizarUnaPersona(@PathVariable Long id, @RequestBody Persona p) {

//         Persona personaBuscada = persoRepo.findById(id).get();

//         personaBuscada.setNombre(p.getNombre());
//         personaBuscada.setEdad(p.getEdad());

//         persoRepo.save(personaBuscada);

//         return "Datos de la persona actualizada correctamente";
//     }


//     @GetMapping("persona/buscar/{nombre}")
//     public ResponseEntity<List<Persona>> buscarPorNombre(@PathVariable String nombre) {
//         List<Persona> personas = personaService.buscarPorNombre(nombre);
//         return ResponseEntity.ok(personas);
//     }

//     @GetMapping("persona/buscarSimilar/{cadena}")
//     public ResponseEntity<List<Persona>> buscarPorNombreSimilar(@PathVariable String cadena) {
//         List<Persona> personas = personaService.buscarPersonasPorNombreSimilar(cadena);
//         return ResponseEntity.ok(personas);
//     }

}
