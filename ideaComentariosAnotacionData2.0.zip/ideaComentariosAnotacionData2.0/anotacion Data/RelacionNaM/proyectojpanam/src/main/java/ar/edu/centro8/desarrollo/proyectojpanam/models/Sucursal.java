// -----------------------------------------------------------------

/*El anotador @Data de Lombok genera los siguientes métodos automáticamente para la clase anotada:

Constructor vacío (default())
Constructor con todos los campos (allArgsConstructor())
Método getter para cada campo (getter())
Método setter para cada campo (setter())
Método toString() que incluye todos los campos de la clase
Método equals() y hashCode() basados en todos los campos de la clase*/

// -- package ar.edu.centro8.desarrollo.proyectosbon2.model;

// import lombok.Data;

// @Data
// public class Sucursal {
    
//     private Long id_sucursal;
//     private String localidad;
//     private String direccion;
//     private String producto;

//     //private Instant fechaActualizacion;

// }

// --------------------------intento anterior------------------------------------


package ar.edu.centro8.desarrollo.proyectojpanam.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.ArrayList;

@Entity
@Table(name = "sucursal")
@NoArgsConstructor
@Getter @Setter
public class Sucursal {
    @Id @Column(name = "id_sucursal", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idSucursal;

    @Column(name = "localidad", nullable = false)
    private String localidad;

    @Column(name = "direccion", nullable = false)
    private String direccion;

    @Column(name = "producto", nullable = false)
    private String producto;

    @ManyToMany(mappedBy = "sucursales")
    @JsonManagedReference
    private List<Producto> productos = new ArrayList<>();

    //construsctor parametrizado:

    public Sucursal(Long idSucursal, String localidad, String direccion, String producto, List<Producto> productos) {
        this.idSucursal = idSucursal;
        this.localidad = localidad;
        this.direccion = direccion;
        this.producto = producto;
        this.productos = productos;
    }

    // ---------------esta parte da errores ---------------
    // --------sabes? en realidad me parece que no es necesaria ---------

    // public Producto(Long idProducto) {
    //     this.idProducto = idProducto;
    // }

    // public void agregarProducto(Producto producto) {
    //     if (productos == null) {
    //         productos = new ArrayList<>();
    //     }
    //     productos.add(producto);
    // }
    
}
