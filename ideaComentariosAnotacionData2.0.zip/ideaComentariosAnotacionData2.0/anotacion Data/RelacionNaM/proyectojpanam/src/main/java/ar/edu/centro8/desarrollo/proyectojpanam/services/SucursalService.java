package ar.edu.centro8.desarrollo.proyectojpanam.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.edu.centro8.desarrollo.proyectojpanam.dto.SucursalRequestDTO;
import ar.edu.centro8.desarrollo.proyectojpanam.dto.ProductoRequestDTO;
import ar.edu.centro8.desarrollo.proyectojpanam.models.Sucursal;
import ar.edu.centro8.desarrollo.proyectojpanam.models.Producto;
import ar.edu.centro8.desarrollo.proyectojpanam.repositories.SucursalRepository;
import ar.edu.centro8.desarrollo.proyectojpanam.repositories.ProductoRepository;
import jakarta.transaction.Transactional;

@Service
public class SucursalService {
    @Autowired
    private SucursalRepository sucursalRepository;

    @Autowired
    private ProductoRepository estudianteRepository;

    @Transactional
    public Sucursal crearSucursalConProducto(SucursalRequestDTO sucursalRequest) {
        Sucursal sucursal = new Sucursal(sucursalRequest.getNombre());
        
        for (ProductoRequestDTO producto : sucursalRequest.getProducto()) {
            Producto productoNuevo = new Producto(producto.getNombre());
            productoNuevo.agregarSucursal(sucursal);
            sucursal.agregarProducto(productoNuevo);
            productoRepository.save(productoNuevo);
        }
        
        return sucursalRepository.save(sucursal);
    }
}
