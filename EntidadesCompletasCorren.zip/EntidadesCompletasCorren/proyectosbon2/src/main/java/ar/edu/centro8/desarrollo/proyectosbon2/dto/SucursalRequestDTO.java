package ar.edu.centro8.desarrollo.proyectosbon2.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SucursalRequestDTO {
    private String nombre;
    private List<ProductoRequestDTO> estudiantes;
}
