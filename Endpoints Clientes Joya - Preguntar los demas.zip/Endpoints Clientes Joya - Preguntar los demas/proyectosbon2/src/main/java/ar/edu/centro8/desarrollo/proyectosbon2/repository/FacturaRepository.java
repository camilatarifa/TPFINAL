package ar.edu.centro8.desarrollo.proyectosbon2.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import ar.edu.centro8.desarrollo.proyectosbon2.model.Factura;

@Repository
public interface FacturaRepository extends JpaRepository<Factura, Long> {

    @Query("SELECT f FROM Factura f WHERE LOWER(f.formaDePago) LIKE LOWER(?1)")
    List<Factura> findByFormaDePagoContaining(String formaDePago);

    @Query("SELECT f FROM Factura f WHERE LOWER(f.formaDePago) LIKE LOWER(CONCAT(:formaDePago, '%'))")
    List<Factura> findByFormaDePagoLike(@Param("formaDePago") String formaDePago);
}