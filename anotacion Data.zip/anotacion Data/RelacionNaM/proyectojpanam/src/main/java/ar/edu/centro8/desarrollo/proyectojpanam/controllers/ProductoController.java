/*
La llamada optionalEstudiante.isPresent() realiza la siguiente función:

Comprueba si hay un valor presente dentro del Optional.
Devuelve un booleano:
Si hay un valor presente, devuelve true.
Si no hay ningún valor, devuelve false.
Es una forma de verificar si el Optional contiene algún elemento sin acceder directamente al contenido.



Optional es una clase en Java que representa un valor que puede o no estar presente. Es parte del paquete java.util y fue introducido en Java 8. Sus principales características son:

Representa un valor que puede o no estar presente.
Permite manejar casos donde un valor podría no existir sin necesidad de usar null.
Ofrece métodos para verificar si tiene un valor y acceder a él de manera segura.
Es particularmente útil en combinación con funciones lambda y expresiones de interfaz.
Es usado por Spring Data JPA en métodos como findById() para indicar que el resultado puede ser nulo.
 */

package ar.edu.centro8.desarrollo.proyectojpanam.controllers;

import ar.edu.centro8.desarrollo.proyectojpanam.models.Sucursal;
import ar.edu.centro8.desarrollo.proyectojpanam.models.Producto;
import ar.edu.centro8.desarrollo.proyectojpanam.repositories.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/productos")
public class ProductoController {

    @Autowired
    private ProductoRepository productoRepository;

    @GetMapping
    public void traerProductos() {
        List<Producto> producto = productoRepository.findAll();
    }

    @GetMapping("/{idProducto}")
    public void traerProductoPorId(@PathVariable Long idProducto) {
        productoRepository.findById(idProducto);
    }

    @PostMapping
    public void crearProducto(@RequestBody Producto producto) {
        productoRepository.save(producto);
    }

    @PutMapping("/editar/producto/{idProducto}")
    public void editarProducto(@PathVariable Long idProducto,
            @RequestParam(required = false, name = "id") Long nuevaId,
            @RequestParam(required = false, name = "nombre") String nuevoNombre) {
        Optional<Producto> optionalProducto = productoRepository.findById(idProducto);
        if (optionalProducto.isPresent()) {
            Producto existingProducto = optionalProducto.get();
            existingProducto.setNombre(nuevoNombre);
            productoRepository.save(existingProducto);
        } else {
            // Manejar el caso en que el producto no existe
        }

    }

    @DeleteMapping("/{idProducto}")
    public void eliminarProducto(@PathVariable Long idProducto) {
        productoRepository.deleteById(idProducto);
    }

}
