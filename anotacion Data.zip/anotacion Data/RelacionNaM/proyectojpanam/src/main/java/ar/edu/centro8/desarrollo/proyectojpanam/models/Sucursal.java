// -----------------------------------------------------------------

/*El anotador @Data de Lombok genera los siguientes métodos automáticamente para la clase anotada:

Constructor vacío (default())
Constructor con todos los campos (allArgsConstructor())
Método getter para cada campo (getter())
Método setter para cada campo (setter())
Método toString() que incluye todos los campos de la clase
Método equals() y hashCode() basados en todos los campos de la clase*/

// -- package ar.edu.centro8.desarrollo.proyectosbon2.model;

// import lombok.Data;

// @Data
// public class Sucursal {
    
//     private Long id_sucursal;
//     private String localidad;
//     private String direccion;
//     private String producto;

//     //private Instant fechaActualizacion;

// }

// --------------------------intento anterior------------------------------------


package ar.edu.centro8.desarrollo.proyectojpanam.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.ArrayList;

@Entity
@NoArgsConstructor
@Getter @Setter
public class Sucursal {
    @Id @Column(name = "id_sucursal", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idSucursal;

    @Column(name = "localidad", nullable = false)
    private String localidad;

    @Column(name = "direccion", nullable = false)
    private String direccion;

    @Column(name = "producto", nullable = false)
    private String producto;

    @ManyToMany(mappedBy = "sucursales")
    @JsonManagedReference
    private List<Producto> productos = new ArrayList<>();

    // ---------------esta parte da errores ---------------

    // public Sucursal(String idSucursal, List<Producto> productos) {
    //     this.idSucursal = idSucursal;
    //     this.productos = productos;
    // }

    // public Sucursal(String idSucursal) {
    //     this.idSucursal = idSucursal;
    // }

    // public void agregarEstudiante(Producto producto) {
    //     if (productos == null) {
    //         productos = new ArrayList<>();
    //     }
    //     productos.add(producto);
    // }
    
}
