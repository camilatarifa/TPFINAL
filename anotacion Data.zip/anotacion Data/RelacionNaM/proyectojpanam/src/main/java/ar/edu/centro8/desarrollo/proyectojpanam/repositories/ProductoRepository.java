package ar.edu.centro8.desarrollo.proyectojpanam.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.centro8.desarrollo.proyectojpanam.models.Producto;

public interface ProductoRepository extends JpaRepository<Producto,Long> {

}
