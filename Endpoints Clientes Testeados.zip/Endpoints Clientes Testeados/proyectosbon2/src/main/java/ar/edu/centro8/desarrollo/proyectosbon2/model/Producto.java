package ar.edu.centro8.desarrollo.proyectosbon2.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.ArrayList;

@Entity
@Table(name = "producto")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idProducto;

    @Column(nullable = false)
    private String nombre_producto;

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JsonBackReference
    @JoinTable(
        name = "producto_sucursal",
        joinColumns = @JoinColumn(name = "idProducto"),
        inverseJoinColumns = @JoinColumn(name = "idSucursal")
    )
    private List<Sucursal> sucursales = new ArrayList<>();

    public Producto(String nombre, List<Sucursal> sucursales) {
        this.nombre_producto = nombre;
        this.sucursales = sucursales;
    }

    public Producto(String nombre) {
        this.nombre_producto = nombre;
    }

    public void agregarSucursal(Sucursal sucursal) {
        if (sucursales == null) {
            sucursales = new ArrayList<>();
        }
        sucursales.add(sucursal);
    }
}
