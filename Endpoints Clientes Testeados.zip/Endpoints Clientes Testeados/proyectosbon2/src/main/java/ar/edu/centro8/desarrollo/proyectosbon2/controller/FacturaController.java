package ar.edu.centro8.desarrollo.proyectosbon2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.centro8.desarrollo.proyectosbon2.repository.FacturaRepository;
import ar.edu.centro8.desarrollo.proyectosbon2.service.FacturaService;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Factura;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })
public class FacturaController {

    @Autowired
    private FacturaRepository facturaRepository;

    @Autowired
    private FacturaService facturaService;

    @GetMapping("/factura/traer")
    public List<Factura> traerFacturas() {
        return facturaRepository.findAll();
    }

    @GetMapping("/factura/traer/{id}")
    public Optional<Factura> traerUnaFactura(@PathVariable Long id) {
        return facturaRepository.findById(id);
    }

    @PostMapping("/factura/crear")
    public void crearFactura(@RequestBody Factura f) {
        facturaRepository.save(f);
    }

    @DeleteMapping("/factura/borrar/{id}")
    public String borrarUnaFactura(@PathVariable Long id) {
        facturaRepository.deleteById(id);
        return "Factura eliminada correctamente";
    }

    @PutMapping("/factura/actualizar/{id}")
    public String actualizarUnaFactura(@PathVariable Long id, @RequestBody Factura f) {

        Factura facturaBuscada = facturaRepository.findById(id).get();

        facturaBuscada.setFormaDePago(f.getFormaDePago());
        facturaBuscada.setNro_pedido(f.getNro_pedido());

        facturaRepository.save(facturaBuscada);

        return "Datos de la factura actualizados correctamente";
    }

    @GetMapping("/factura/buscar/{formaDePago}")
    public ResponseEntity<List<Factura>> buscarPorFormaDePago(@PathVariable String formaDePago) {
        List<Factura> facturas = facturaService.buscarPorFormaDePago(formaDePago);
        return ResponseEntity.ok(facturas);
    }

    @GetMapping("/factura/buscarSimilar/{cadena}")
    public ResponseEntity<List<Factura>> buscarPorFormaDePagoSimilar(@PathVariable String cadena) {
        List<Factura> facturas = facturaService.buscarFacturasPorFormaDePagoSimilar(cadena);
        return ResponseEntity.ok(facturas);
    }
}