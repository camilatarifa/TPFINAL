package com.example.demo.Service;

import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.Model.Cliente;
import com.example.demo.Repository.ClienteRepository;
import jakarta.transaction.Transactional;

@Service
@Transactional

public class ClienteService {
    @Autowired
    private ClienteRepository clienteRepository;

    public List<Cliente> obtenerClientes() {
        return clienteRepository.findAll();
    }

    public Cliente guardarCliente(Cliente cliente) {
        return clienteRepository.save(cliente);
    }

    public boolean eliminarCliente(Long id) {
        try {
            clienteRepository.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public Cliente traerCliente(Long id) {
        return clienteRepository.findById(id).orElse(null);
    }

    public Cliente editarCliente(Long idOriginal, Long idNueva, int nuevoId_cliente, String nuevoNombre,
            String nuevoDomicilio, char nuevodni, String nuevotelefono) {
        Cliente cliente = traerCliente(idOriginal);
        if (cliente != null) {
            cliente.setId(idNueva);
            cliente.setId_cliente(nuevoId_cliente);
            cliente.setNombre(nuevoNombre);
            cliente.setDomicilio(nuevoDomicilio);
            cliente.setDni(nuevodni);
            cliente.setTelefono(nuevotelefono);
            return guardarCliente(cliente);
        }
        return null;
    }
}