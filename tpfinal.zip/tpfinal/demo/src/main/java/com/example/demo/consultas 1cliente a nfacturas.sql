-- Active: 1717524682167@@127.0.0.1@3306@cafeteria
SELECT * FROM JpaRepository; -- no se q hacer :´(
SELECT * from clientes;
SELECT * from facturas;
SELECT * FROM productos;
SELECT * from sucursales;


SELECT * from cliente c INNER JOIN factura f ON f.id_factura = c.id_factura; -- error 