package com.example.demo.Model;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import java.util.HashSet;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.var;

@Entity
@NoArgsConstructor
@Getter
@Setter

public class Factura {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name = "id_factura", nullable = false)
    private Long id;
    // no se si va, ¿Va valen? se me gen, pero lo puse en hashCode

    @Column(name = "letra", nullable = false)
    private char letra;

    @Column(name = "nro_pedido", nullable = false)
    private int nro_pedido;

    // @Column(name = "fecha", nullable = false)
    // private String fecha; //Como hago con en Date?

    @Column(name = "id_producto", nullable = false)
    private int id_producto;

    @Column(name = "id_cliente", nullable = false)
    private int id_cliente;

    @Column(name = "id_sucursal", nullable = false)
    private int id_sucursal;

    @Column(name = "forma_de_pago", nullable = false)
    private int forma_de_pago; // en lo q me mandas es el varchar

    @OneToMany(mappedBy = "factura", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference

    private List<Cliente> clientes;

    public Factura(char letra, int nro_pedido, int id_producto, int id_cliente, int id_sucursal, int forma_de_pago,
            List<Cliente> clientes) {
        this.letra = letra;
        this.nro_pedido = nro_pedido;
        this.id_producto = id_producto;
        this.id_cliente = id_cliente;
        this.forma_de_pago = forma_de_pago;
        this.clientes = clientes;
    }

    public Cliente agregarCliente(Cliente cliente) {
        this.clientes.add(cliente);
        return cliente;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((letra == null) ? 0 : letra.hashCode());
        result = prime * result + ((nro_pedido == null) ? 0 : nro_pedido.hashCode());
        result = prime * result + ((id_producto == null) ? 0 : id_producto.hashCode());
        result = prime * result + ((id_cliente == null) ? 0 : id_cliente.hashCode());
        result = prime * result + ((id_sucursal == null) ? 0 : id_sucursal.hashCode());
        result = prime * result + ((forma_de_pago == null) ? 0 : forma_de_pago.hashCode())
        result = prime * result + ((clientes == null) ? 0 : clientes.hashCode());
        return result;
    } // arreglar el error

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Factura other = (Factura) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (letra == null) {
            if (other.letra != null)
                return false;
        } else if (!letra.equals(other.letra))
            return false;
        if (clientes == null) {
            if (other.clientes != null)
                return false;
        } else if (!clientes.equals(other.clientes))
            return false;
        return true;
    }
}
