package com.example.demo.Model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Getter
@Setter

public class Cliente {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_cliente", nullable = false)
    private int id_cliente;
    @Column(name = "nombre", nullable = false)
    private String nombre;
    @Column(name = "domicilio", nullable = false)
    private String domicilio;
    @Column(name = "dni", nullable = false)
    private char dni;
    @Column(name = "telefono", nullable = false)
    private String telefono;

    @ManyToOne
    @JsonBackReference
    @JoinColumn(name = "id_factura")
    private Factura factura;

    public Cliente(int id_cliente, String nombre, String domicilio, char dni, String telefono, Factura factura) {
        this.id_cliente = id_cliente;
        this.nombre = nombre;
        this.domicilio = domicilio;
        this.dni = dni;
        this.telefono = telefono;
        this.factura = factura;
    }

    // YO camila, cambiar el nombbre de sucursal x factura, ya lo hice x factura
    // AGREGADO
    public void setConcesionaria(Factura factura) {
        this.factura = factura;
    }

}