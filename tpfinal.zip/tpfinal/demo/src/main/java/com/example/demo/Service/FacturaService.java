package com.example.demo.Service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Cliente;
import com.example.demo.Model.Factura;
import com.example.demo.Repository.ClienteRepository;
import com.example.demo.Repository.FacturaRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class FacturaService {
@Autowired
    private FacturaRepository facturaRepository;

    @Autowired
    private ClienteRepository clienteRepository;

    
    public List<Factura> obtenerFacturas() {
        return facturaRepository.findAll();
    }

    public Factura guardarFactura(Factura factura) {
        return facturaRepository.save(factura);
    }

    public boolean eliminarFactura(Long id) {
        try {
            facturaRepository.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public Factura traerFactura(Long id) {
        return facturaRepository.findById(id).orElse(null);
    }
    public Factura editarFactura(Long idOriginal, char nuevaletra, int nuevonro_pedido, int id_producto, int id_cliente, int id_sucursal, String forma_de_pago) {
        Factura factura = traerFactura(idOriginal);
        if (factura != null) {
            factura.setLetra(nuevaletra);
            factura.setNro_pedido(nuevonro_pedido);
            factura.setId_producto(id_producto);
            factura.setId_cliente(id_cliente);
            factura.setId_sucursal(id_sucursal);
            factura.setForma_de_pago(forma_de_pago);
            return guardarFactura(factura);
        }
        return null;
    }

    public Cliente guardarCliente(Cliente cliente) {
        return clienteRepository.save(cliente);
    }

   

}
