package com.example.demo.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Cliente;
import com.example.demo.Model.Factura;
import com.example.demo.Service.FacturaService;

@RestController
@RequestMapping("/api/facturas")
public class FacturaController {

    @Autowired
    private FacturaService facturaService;

    @GetMapping
    public List<Factura> getAllFacturas() {
        return facturaService.obtenerFacturas();
    }

    @GetMapping("/{id}")
    public Factura getFacturaById(@PathVariable Long id) {
        return facturaService.traerFactura(id);
    }

    @PostMapping
    public void createFactura(@RequestBody Factura factura) {
        facturaService.guardarFactura(factura);
    }

    @PutMapping("/{id}")
    public void updateFactura(@PathVariable Long id, @RequestBody Factura factura) {
 facturaService.editarFactura(
                id, factura.getLetra(), factura.getNro_pedido(), 
                factura.getId_producto(), factura.getId_cliente(), factura.getId_sucursal(),factura.getForma_de_pago()
            );
        }

    @DeleteMapping("/{id}")
    public void deleteConcesionaria(@PathVariable Long id) {
        facturaService.eliminarFactura(id);
    }

    @PostMapping("/{id}/clientes")
    public ResponseEntity<?> createClienteForFactura(
            @PathVariable Long id,
            @RequestBody Cliente cliente) {
        Factura factura = facturaService.traerFactura(id);
        if (factura == null) {
            return ResponseEntity.notFound().build();
        }

        cliente.setFactura(factura);
        facturaService.guardarCliente(cliente);

        return ResponseEntity.ok("Cliente creado exitosamente");
    }
}
