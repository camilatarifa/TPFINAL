// -----------------------------------------------------------------

/*El anotador @Data de Lombok genera los siguientes métodos automáticamente para la clase anotada:

Constructor vacío (default())
Constructor con todos los campos (allArgsConstructor())
Método getter para cada campo (getter())
Método setter para cada campo (setter())
Método toString() que incluye todos los campos de la clase
Método equals() y hashCode() basados en todos los campos de la clase*/

// -- package ar.edu.centro8.desarrollo.proyectosbon2.model;

// import lombok.Data;

// @Data
// public class Producto {

//     private Long id_producto;
//     private String codigo_sucursal;
//     private String categoria;
//     private String producto;
//     private Double precio;
//     private int stock_actual;
//     private int stock_minimo;
//     private int stock_maximo;
//     //private Instant fechaActualizacion;

// }

// --------------------------intento anterior------------------------------------

package com.example.demo.Model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.ArrayList;

@Entity
@Table(name = "producto")
@NoArgsConstructor
@Getter
@Setter
public class Producto {
    @Id
    @Column(name = "id_producto", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idProducto;

    @Column(name = "id_sucursal", nullable = false)
    private Long idSucursal;

    @Column(name = "categoria", nullable = false)
    private String categoria;

    @Column(name = "producto", nullable = false)
    private String producto;

    @Column(name = "precio", nullable = false)
    private Double precio;

    @Column(name = "stock_actual", nullable = false)
    private int stockActual;

    @Column(name = "stock_minimo", nullable = false)
    private int stockMinimo;

    @Column(name = "stock_maximo", nullable = false)
    private int stockMaximo;

    @ManyToMany(mappedBy = "productos")
    @JsonManagedReference
    private List<Producto> productos = new ArrayList<>();

    // construsctor parametrizado:

    public Producto(Long idProducto, Long idSucursal, String categoria, String producto, Double precio, int stockActual,
            int stockMinimo, int stockMaximo, List<Producto> productos) {
        this.idProducto = idProducto;
        this.idSucursal = idSucursal;
        this.categoria = categoria;
        this.producto = producto;
        this.precio = precio;
        this.stockActual = stockActual;
        this.stockMinimo = stockMinimo;
        this.stockMaximo = stockMaximo;
        this.productos = productos;

    }

    public Producto(String Producto) {
        this.producto = producto;
    }

    private List<Sucursal> sucursales = new ArrayList<>();

    public void agregarSucursal(Sucursal sucursal) {
        if (sucursales == null) {
            sucursales = new ArrayList<>();
        }
        sucursales.add(sucursal);
    }
    // ---------------esta parte da errores ---------------

    // public Sucursal(String idSucursal) {
    // this.idSucursal = idSucursal;
    // }

    // public void agregarEstudiante(Producto producto) {
    // if (productos == null) {
    // productos = new ArrayList<>();
    // }
    // productos.add(producto);
    // }

}
