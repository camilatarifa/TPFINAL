-- Active: 1732412945798@@127.0.0.1@3306
SELECT * FROM JpaRepository; -- no se q hacer :´(
SELECT * from clientes;
SELECT * from facturas;
SELECT * FROM productos;
SELECT * from sucursales;

