package com.example.demo.controllers;

import com.example.demo.dto.SucursalRequestDTO;
import com.example.demo.Model.Sucursal;
import com.example.demo.Model.Producto;
// import ar.edu.centro8.desarrollo.proyectojpanam.models.Sucursal;
import com.example.demo.Repository.SucursalRepository;
import com.example.demo.Repository.ProductoRepository;
import com.example.demo.Service.SucursalService;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sucursales")
public class SucursalController {
    @Autowired
    private SucursalRepository sucursalRepository;

    @Autowired
    private SucursalService sucursalService;

    @GetMapping("sucursal/buscar/{producto}")
    public void traerSucursales() {
        List<Sucursal> sucursales = sucursalRepository.findAll();
    }

    @GetMapping("/{idSucursal}")
    public void traerSucursalPorId(@PathVariable Long idSucursal) {
        sucursalRepository.findById(idSucursal);
    }

    // @PostMapping
    // public void crearSucursal(@RequestBody Sucursal sucursal) {
    // sucursalRepository.save(sucursal);
    // }

    @PutMapping("/editar/sucursal/{idSucursal}")
    public void editarSucursal(@PathVariable Long idSucursal,
            @RequestParam(required = false, name = "id_sucursal") Long nuevaId_sucursal,
            @RequestParam(required = false, name = "localidad") String nuevaLocalidad,
            @RequestParam(required = false, name = "direccion") String nuevaDireccion,
            @RequestParam(required = false, name = "producto") String nuevoProducto
            
            ) {
        Optional<Sucursal> optionalSucursal = sucursalRepository.findById(idSucursal);
        if (optionalSucursal.isPresent()) {
            Sucursal existingSucursal = optionalSucursal.get();
            existingSucursal.setLocalidad(nuevaLocalidad);
            existingSucursal.setDireccion(nuevaDireccion);
            existingSucursal.setProducto(nuevoProducto);
            sucursalRepository.save(existingSucursal);
        } else {
            // Manejar el caso en que la sucursal no exista
        }
    }

    @DeleteMapping("/sucursal/{idSucursal}")
    public void eliminarSucursal(@PathVariable Long idSucursal) {
        sucursalRepository.deleteById(idSucursal);
    }

    @PostMapping
    public ResponseEntity<Sucursal> crearSucursal(@RequestBody SucursalRequestDTO sucursalRequest) {
        Sucursal sucursal = sucursalService.crearSucursalConProducto(sucursalRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(sucursal);
    }

}
